﻿
namespace Final
{
    partial class Buy
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.Doblbl = new System.Windows.Forms.Label();
            this.namelbl = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.Malerb = new System.Windows.Forms.RadioButton();
            this.Femalerb = new System.Windows.Forms.RadioButton();
            this.Passporttb = new System.Windows.Forms.TextBox();
            this.Nationalitytb = new System.Windows.Forms.TextBox();
            this.Lnametb = new System.Windows.Forms.TextBox();
            this.FlightDate = new System.Windows.Forms.DateTimePicker();
            this.DOB = new System.Windows.Forms.DateTimePicker();
            this.ttypelbl = new System.Windows.Forms.Label();
            this.passlbl = new System.Windows.Forms.Label();
            this.fldatelbl = new System.Windows.Forms.Label();
            this.urflightlbl = new System.Windows.Forms.Label();
            this.gdrlbl = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.psplbl = new System.Windows.Forms.Label();
            this.Natlbl = new System.Windows.Forms.Label();
            this.Lastnamelbl = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.Nametb = new System.Windows.Forms.TextBox();
            this.SearchBox = new System.Windows.Forms.TextBox();
            this.clrbtn = new System.Windows.Forms.Button();
            this.Closebtn = new System.Windows.Forms.Button();
            this.upbtn = new System.Windows.Forms.Button();
            this.delbtn = new System.Windows.Forms.Button();
            this.addbtn = new System.Windows.Forms.Button();
            this.FlightdG = new System.Windows.Forms.DataGridView();
            this.nODataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.yourFlightDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nameDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lastNameDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nationalityDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.passportDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dOBDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.genderDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ticketTypeDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.passengersDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.flightDateDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.purchase1BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.flightDataSet2 = new Final.FlightDataSet2();
            this.purchaseBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.flightDataSet1 = new Final.FlightDataSet1();
            this.YourFlightCB = new System.Windows.Forms.ComboBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.Burb = new System.Windows.Forms.RadioButton();
            this.Ecorb = new System.Windows.Forms.RadioButton();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.Infantrb = new System.Windows.Forms.RadioButton();
            this.Adultrb = new System.Windows.Forms.RadioButton();
            this.Childrb = new System.Windows.Forms.RadioButton();
            this.purchaseBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.purchaseTableAdapter = new Final.FlightDataSet1TableAdapters.PurchaseTableAdapter();
            this.yourFlightDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lastNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nationalityDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.passportDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dOBDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.genderDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ticketTypeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.passengersDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.flightDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label3 = new System.Windows.Forms.Label();
            this.purchase1TableAdapter = new Final.FlightDataSet2TableAdapters.Purchase1TableAdapter();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.NOlbl = new System.Windows.Forms.Label();
            this.NOtb = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.FlightdG)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.purchase1BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.flightDataSet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.purchaseBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.flightDataSet1)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.purchaseBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // Doblbl
            // 
            this.Doblbl.AutoSize = true;
            this.Doblbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.Doblbl.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.Doblbl.Location = new System.Drawing.Point(-97, 224);
            this.Doblbl.Name = "Doblbl";
            this.Doblbl.Size = new System.Drawing.Size(36, 15);
            this.Doblbl.TabIndex = 41;
            this.Doblbl.Text = "DOB";
            // 
            // namelbl
            // 
            this.namelbl.AutoSize = true;
            this.namelbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.namelbl.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.namelbl.Location = new System.Drawing.Point(-97, 47);
            this.namelbl.Name = "namelbl";
            this.namelbl.Size = new System.Drawing.Size(45, 15);
            this.namelbl.TabIndex = 37;
            this.namelbl.Text = "Name";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.Malerb);
            this.groupBox1.Controls.Add(this.Femalerb);
            this.groupBox1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox1.Location = new System.Drawing.Point(178, 268);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(160, 15);
            this.groupBox1.TabIndex = 66;
            this.groupBox1.TabStop = false;
            // 
            // Malerb
            // 
            this.Malerb.AutoSize = true;
            this.Malerb.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.Malerb.Location = new System.Drawing.Point(0, 0);
            this.Malerb.Name = "Malerb";
            this.Malerb.Size = new System.Drawing.Size(48, 17);
            this.Malerb.TabIndex = 25;
            this.Malerb.TabStop = true;
            this.Malerb.Text = "Male";
            this.Malerb.UseVisualStyleBackColor = true;
            // 
            // Femalerb
            // 
            this.Femalerb.AutoSize = true;
            this.Femalerb.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.Femalerb.Location = new System.Drawing.Point(105, 0);
            this.Femalerb.Name = "Femalerb";
            this.Femalerb.Size = new System.Drawing.Size(59, 17);
            this.Femalerb.TabIndex = 26;
            this.Femalerb.TabStop = true;
            this.Femalerb.Text = "Female";
            this.Femalerb.UseVisualStyleBackColor = true;
            // 
            // Passporttb
            // 
            this.Passporttb.Location = new System.Drawing.Point(178, 189);
            this.Passporttb.Name = "Passporttb";
            this.Passporttb.Size = new System.Drawing.Size(164, 20);
            this.Passporttb.TabIndex = 65;
            // 
            // Nationalitytb
            // 
            this.Nationalitytb.Location = new System.Drawing.Point(178, 148);
            this.Nationalitytb.Name = "Nationalitytb";
            this.Nationalitytb.Size = new System.Drawing.Size(164, 20);
            this.Nationalitytb.TabIndex = 64;
            // 
            // Lnametb
            // 
            this.Lnametb.Location = new System.Drawing.Point(178, 103);
            this.Lnametb.Name = "Lnametb";
            this.Lnametb.Size = new System.Drawing.Size(164, 20);
            this.Lnametb.TabIndex = 63;
            // 
            // FlightDate
            // 
            this.FlightDate.Location = new System.Drawing.Point(178, 429);
            this.FlightDate.Name = "FlightDate";
            this.FlightDate.Size = new System.Drawing.Size(164, 20);
            this.FlightDate.TabIndex = 62;
            // 
            // DOB
            // 
            this.DOB.Location = new System.Drawing.Point(178, 234);
            this.DOB.Name = "DOB";
            this.DOB.Size = new System.Drawing.Size(164, 20);
            this.DOB.TabIndex = 61;
            // 
            // ttypelbl
            // 
            this.ttypelbl.AutoSize = true;
            this.ttypelbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.ttypelbl.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.ttypelbl.Location = new System.Drawing.Point(-1, 308);
            this.ttypelbl.Name = "ttypelbl";
            this.ttypelbl.Size = new System.Drawing.Size(112, 15);
            this.ttypelbl.TabIndex = 60;
            this.ttypelbl.Text = "Your Ticket Type";
            // 
            // passlbl
            // 
            this.passlbl.AutoSize = true;
            this.passlbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.passlbl.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.passlbl.Location = new System.Drawing.Point(-1, 350);
            this.passlbl.Name = "passlbl";
            this.passlbl.Size = new System.Drawing.Size(82, 15);
            this.passlbl.TabIndex = 59;
            this.passlbl.Text = "Passengers";
            // 
            // fldatelbl
            // 
            this.fldatelbl.AutoSize = true;
            this.fldatelbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.fldatelbl.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.fldatelbl.Location = new System.Drawing.Point(1, 429);
            this.fldatelbl.Name = "fldatelbl";
            this.fldatelbl.Size = new System.Drawing.Size(77, 15);
            this.fldatelbl.TabIndex = 58;
            this.fldatelbl.Text = "Flight Date";
            // 
            // urflightlbl
            // 
            this.urflightlbl.AutoSize = true;
            this.urflightlbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.urflightlbl.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.urflightlbl.Location = new System.Drawing.Point(1, 21);
            this.urflightlbl.Name = "urflightlbl";
            this.urflightlbl.Size = new System.Drawing.Size(80, 15);
            this.urflightlbl.TabIndex = 57;
            this.urflightlbl.Text = "Your Flight ";
            // 
            // gdrlbl
            // 
            this.gdrlbl.AutoSize = true;
            this.gdrlbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.gdrlbl.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.gdrlbl.Location = new System.Drawing.Point(-1, 268);
            this.gdrlbl.Name = "gdrlbl";
            this.gdrlbl.Size = new System.Drawing.Size(54, 15);
            this.gdrlbl.TabIndex = 56;
            this.gdrlbl.Text = "Gender";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label1.Location = new System.Drawing.Point(-1, 234);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(36, 15);
            this.label1.TabIndex = 55;
            this.label1.Text = "DOB";
            // 
            // psplbl
            // 
            this.psplbl.AutoSize = true;
            this.psplbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.psplbl.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.psplbl.Location = new System.Drawing.Point(-1, 190);
            this.psplbl.Name = "psplbl";
            this.psplbl.Size = new System.Drawing.Size(118, 15);
            this.psplbl.TabIndex = 54;
            this.psplbl.Text = "Passport Number";
            // 
            // Natlbl
            // 
            this.Natlbl.AutoSize = true;
            this.Natlbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.Natlbl.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.Natlbl.Location = new System.Drawing.Point(-1, 149);
            this.Natlbl.Name = "Natlbl";
            this.Natlbl.Size = new System.Drawing.Size(75, 15);
            this.Natlbl.TabIndex = 53;
            this.Natlbl.Text = "Nationality";
            // 
            // Lastnamelbl
            // 
            this.Lastnamelbl.AutoSize = true;
            this.Lastnamelbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.Lastnamelbl.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.Lastnamelbl.Location = new System.Drawing.Point(-1, 104);
            this.Lastnamelbl.Name = "Lastnamelbl";
            this.Lastnamelbl.Size = new System.Drawing.Size(72, 15);
            this.Lastnamelbl.TabIndex = 52;
            this.Lastnamelbl.Text = "LastName";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label2.Location = new System.Drawing.Point(-1, 61);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(45, 15);
            this.label2.TabIndex = 51;
            this.label2.Text = "Name";
            // 
            // Nametb
            // 
            this.Nametb.Location = new System.Drawing.Point(178, 60);
            this.Nametb.Name = "Nametb";
            this.Nametb.Size = new System.Drawing.Size(164, 20);
            this.Nametb.TabIndex = 50;
            // 
            // SearchBox
            // 
            this.SearchBox.Location = new System.Drawing.Point(517, 105);
            this.SearchBox.Name = "SearchBox";
            this.SearchBox.Size = new System.Drawing.Size(476, 20);
            this.SearchBox.TabIndex = 49;
            this.SearchBox.TextChanged += new System.EventHandler(this.SearchBox_TextChanged);
            // 
            // clrbtn
            // 
            this.clrbtn.BackColor = System.Drawing.Color.LightSteelBlue;
            this.clrbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.clrbtn.Location = new System.Drawing.Point(789, 387);
            this.clrbtn.Name = "clrbtn";
            this.clrbtn.Size = new System.Drawing.Size(75, 23);
            this.clrbtn.TabIndex = 48;
            this.clrbtn.Text = "Clear";
            this.clrbtn.UseVisualStyleBackColor = false;
            this.clrbtn.Click += new System.EventHandler(this.clrbtn_Click);
            // 
            // Closebtn
            // 
            this.Closebtn.Location = new System.Drawing.Point(897, 387);
            this.Closebtn.Name = "Closebtn";
            this.Closebtn.Size = new System.Drawing.Size(96, 37);
            this.Closebtn.TabIndex = 47;
            this.Closebtn.Text = "Close The Application";
            this.Closebtn.UseVisualStyleBackColor = true;
            this.Closebtn.Click += new System.EventHandler(this.mainbtn_Click);
            // 
            // upbtn
            // 
            this.upbtn.BackColor = System.Drawing.Color.DimGray;
            this.upbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.upbtn.Location = new System.Drawing.Point(682, 387);
            this.upbtn.Name = "upbtn";
            this.upbtn.Size = new System.Drawing.Size(75, 23);
            this.upbtn.TabIndex = 45;
            this.upbtn.Text = "Update";
            this.upbtn.UseVisualStyleBackColor = false;
            this.upbtn.Click += new System.EventHandler(this.upbtn_Click);
            // 
            // delbtn
            // 
            this.delbtn.BackColor = System.Drawing.Color.Red;
            this.delbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.delbtn.Location = new System.Drawing.Point(559, 387);
            this.delbtn.Name = "delbtn";
            this.delbtn.Size = new System.Drawing.Size(75, 23);
            this.delbtn.TabIndex = 44;
            this.delbtn.Text = "Delete";
            this.delbtn.UseVisualStyleBackColor = false;
            this.delbtn.Click += new System.EventHandler(this.delbtn_Click);
            // 
            // addbtn
            // 
            this.addbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.addbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.addbtn.Location = new System.Drawing.Point(440, 387);
            this.addbtn.Name = "addbtn";
            this.addbtn.Size = new System.Drawing.Size(75, 23);
            this.addbtn.TabIndex = 43;
            this.addbtn.Text = "Add";
            this.addbtn.UseVisualStyleBackColor = false;
            this.addbtn.Click += new System.EventHandler(this.addbtn_Click);
            // 
            // FlightdG
            // 
            this.FlightdG.AutoGenerateColumns = false;
            this.FlightdG.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.FlightdG.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.nODataGridViewTextBoxColumn,
            this.yourFlightDataGridViewTextBoxColumn1,
            this.nameDataGridViewTextBoxColumn1,
            this.lastNameDataGridViewTextBoxColumn1,
            this.nationalityDataGridViewTextBoxColumn1,
            this.passportDataGridViewTextBoxColumn1,
            this.dOBDataGridViewTextBoxColumn1,
            this.genderDataGridViewTextBoxColumn1,
            this.ticketTypeDataGridViewTextBoxColumn1,
            this.passengersDataGridViewTextBoxColumn1,
            this.flightDateDataGridViewTextBoxColumn1});
            this.FlightdG.DataSource = this.purchase1BindingSource;
            this.FlightdG.Location = new System.Drawing.Point(440, 141);
            this.FlightdG.Name = "FlightdG";
            this.FlightdG.Size = new System.Drawing.Size(553, 201);
            this.FlightdG.TabIndex = 42;
            this.FlightdG.RowHeaderMouseDoubleClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.FlightdG_RowHeaderMouseDoubleClick);
            // 
            // nODataGridViewTextBoxColumn
            // 
            this.nODataGridViewTextBoxColumn.DataPropertyName = "NO";
            this.nODataGridViewTextBoxColumn.HeaderText = "NO";
            this.nODataGridViewTextBoxColumn.Name = "nODataGridViewTextBoxColumn";
            this.nODataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // yourFlightDataGridViewTextBoxColumn1
            // 
            this.yourFlightDataGridViewTextBoxColumn1.DataPropertyName = "YourFlight";
            this.yourFlightDataGridViewTextBoxColumn1.HeaderText = "YourFlight";
            this.yourFlightDataGridViewTextBoxColumn1.Name = "yourFlightDataGridViewTextBoxColumn1";
            // 
            // nameDataGridViewTextBoxColumn1
            // 
            this.nameDataGridViewTextBoxColumn1.DataPropertyName = "Name";
            this.nameDataGridViewTextBoxColumn1.HeaderText = "Name";
            this.nameDataGridViewTextBoxColumn1.Name = "nameDataGridViewTextBoxColumn1";
            // 
            // lastNameDataGridViewTextBoxColumn1
            // 
            this.lastNameDataGridViewTextBoxColumn1.DataPropertyName = "LastName";
            this.lastNameDataGridViewTextBoxColumn1.HeaderText = "LastName";
            this.lastNameDataGridViewTextBoxColumn1.Name = "lastNameDataGridViewTextBoxColumn1";
            // 
            // nationalityDataGridViewTextBoxColumn1
            // 
            this.nationalityDataGridViewTextBoxColumn1.DataPropertyName = "Nationality";
            this.nationalityDataGridViewTextBoxColumn1.HeaderText = "Nationality";
            this.nationalityDataGridViewTextBoxColumn1.Name = "nationalityDataGridViewTextBoxColumn1";
            // 
            // passportDataGridViewTextBoxColumn1
            // 
            this.passportDataGridViewTextBoxColumn1.DataPropertyName = "Passport";
            this.passportDataGridViewTextBoxColumn1.HeaderText = "Passport";
            this.passportDataGridViewTextBoxColumn1.Name = "passportDataGridViewTextBoxColumn1";
            // 
            // dOBDataGridViewTextBoxColumn1
            // 
            this.dOBDataGridViewTextBoxColumn1.DataPropertyName = "DOB";
            this.dOBDataGridViewTextBoxColumn1.HeaderText = "DOB";
            this.dOBDataGridViewTextBoxColumn1.Name = "dOBDataGridViewTextBoxColumn1";
            // 
            // genderDataGridViewTextBoxColumn1
            // 
            this.genderDataGridViewTextBoxColumn1.DataPropertyName = "Gender";
            this.genderDataGridViewTextBoxColumn1.HeaderText = "Gender";
            this.genderDataGridViewTextBoxColumn1.Name = "genderDataGridViewTextBoxColumn1";
            // 
            // ticketTypeDataGridViewTextBoxColumn1
            // 
            this.ticketTypeDataGridViewTextBoxColumn1.DataPropertyName = "TicketType";
            this.ticketTypeDataGridViewTextBoxColumn1.HeaderText = "TicketType";
            this.ticketTypeDataGridViewTextBoxColumn1.Name = "ticketTypeDataGridViewTextBoxColumn1";
            // 
            // passengersDataGridViewTextBoxColumn1
            // 
            this.passengersDataGridViewTextBoxColumn1.DataPropertyName = "Passengers";
            this.passengersDataGridViewTextBoxColumn1.HeaderText = "Passengers";
            this.passengersDataGridViewTextBoxColumn1.Name = "passengersDataGridViewTextBoxColumn1";
            // 
            // flightDateDataGridViewTextBoxColumn1
            // 
            this.flightDateDataGridViewTextBoxColumn1.DataPropertyName = "FlightDate";
            this.flightDateDataGridViewTextBoxColumn1.HeaderText = "FlightDate";
            this.flightDateDataGridViewTextBoxColumn1.Name = "flightDateDataGridViewTextBoxColumn1";
            // 
            // purchase1BindingSource
            // 
            this.purchase1BindingSource.DataMember = "Purchase1";
            this.purchase1BindingSource.DataSource = this.flightDataSet2;
            // 
            // flightDataSet2
            // 
            this.flightDataSet2.DataSetName = "FlightDataSet2";
            this.flightDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // purchaseBindingSource1
            // 
            this.purchaseBindingSource1.DataMember = "Purchase";
            this.purchaseBindingSource1.DataSource = this.flightDataSet1;
            // 
            // flightDataSet1
            // 
            this.flightDataSet1.DataSetName = "FlightDataSet1";
            this.flightDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // YourFlightCB
            // 
            this.YourFlightCB.FormattingEnabled = true;
            this.YourFlightCB.Items.AddRange(new object[] {
            "Istanbul To Ankara",
            "Istanbul  To Antalya",
            "Antalya To Trabzon",
            "Istanbul To Paris"});
            this.YourFlightCB.Location = new System.Drawing.Point(178, 20);
            this.YourFlightCB.Name = "YourFlightCB";
            this.YourFlightCB.Size = new System.Drawing.Size(164, 21);
            this.YourFlightCB.TabIndex = 67;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.Burb);
            this.groupBox2.Controls.Add(this.Ecorb);
            this.groupBox2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox2.Location = new System.Drawing.Point(178, 308);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(190, 15);
            this.groupBox2.TabIndex = 67;
            this.groupBox2.TabStop = false;
            // 
            // Burb
            // 
            this.Burb.AutoSize = true;
            this.Burb.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.Burb.Location = new System.Drawing.Point(95, 0);
            this.Burb.Name = "Burb";
            this.Burb.Size = new System.Drawing.Size(95, 17);
            this.Burb.TabIndex = 28;
            this.Burb.TabStop = true;
            this.Burb.Text = "Business Class";
            this.Burb.UseVisualStyleBackColor = true;
            // 
            // Ecorb
            // 
            this.Ecorb.AutoSize = true;
            this.Ecorb.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.Ecorb.Location = new System.Drawing.Point(0, 0);
            this.Ecorb.Name = "Ecorb";
            this.Ecorb.Size = new System.Drawing.Size(97, 17);
            this.Ecorb.TabIndex = 27;
            this.Ecorb.TabStop = true;
            this.Ecorb.Text = "Economy Class";
            this.Ecorb.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.Infantrb);
            this.groupBox3.Controls.Add(this.Adultrb);
            this.groupBox3.Controls.Add(this.Childrb);
            this.groupBox3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox3.Location = new System.Drawing.Point(178, 350);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(58, 73);
            this.groupBox3.TabIndex = 68;
            this.groupBox3.TabStop = false;
            // 
            // Infantrb
            // 
            this.Infantrb.AutoSize = true;
            this.Infantrb.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.Infantrb.Location = new System.Drawing.Point(6, 50);
            this.Infantrb.Name = "Infantrb";
            this.Infantrb.Size = new System.Drawing.Size(52, 17);
            this.Infantrb.TabIndex = 27;
            this.Infantrb.TabStop = true;
            this.Infantrb.Text = "Infant";
            this.Infantrb.UseVisualStyleBackColor = true;
            this.Infantrb.CheckedChanged += new System.EventHandler(this.radioButton3_CheckedChanged);
            // 
            // Adultrb
            // 
            this.Adultrb.AutoSize = true;
            this.Adultrb.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.Adultrb.Location = new System.Drawing.Point(5, 4);
            this.Adultrb.Name = "Adultrb";
            this.Adultrb.Size = new System.Drawing.Size(49, 17);
            this.Adultrb.TabIndex = 25;
            this.Adultrb.TabStop = true;
            this.Adultrb.Text = "Adult";
            this.Adultrb.UseVisualStyleBackColor = true;
            // 
            // Childrb
            // 
            this.Childrb.AutoSize = true;
            this.Childrb.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.Childrb.Location = new System.Drawing.Point(6, 27);
            this.Childrb.Name = "Childrb";
            this.Childrb.Size = new System.Drawing.Size(48, 17);
            this.Childrb.TabIndex = 26;
            this.Childrb.TabStop = true;
            this.Childrb.Text = "Child";
            this.Childrb.UseVisualStyleBackColor = true;
            // 
            // purchaseBindingSource
            // 
            this.purchaseBindingSource.DataMember = "Purchase";
            this.purchaseBindingSource.DataSource = this.flightDataSet1;
            // 
            // purchaseTableAdapter
            // 
            this.purchaseTableAdapter.ClearBeforeFill = true;
            // 
            // yourFlightDataGridViewTextBoxColumn
            // 
            this.yourFlightDataGridViewTextBoxColumn.DataPropertyName = "YourFlight";
            this.yourFlightDataGridViewTextBoxColumn.HeaderText = "YourFlight";
            this.yourFlightDataGridViewTextBoxColumn.Name = "yourFlightDataGridViewTextBoxColumn";
            // 
            // nameDataGridViewTextBoxColumn
            // 
            this.nameDataGridViewTextBoxColumn.DataPropertyName = "Name";
            this.nameDataGridViewTextBoxColumn.HeaderText = "Name";
            this.nameDataGridViewTextBoxColumn.Name = "nameDataGridViewTextBoxColumn";
            // 
            // lastNameDataGridViewTextBoxColumn
            // 
            this.lastNameDataGridViewTextBoxColumn.DataPropertyName = "LastName";
            this.lastNameDataGridViewTextBoxColumn.HeaderText = "LastName";
            this.lastNameDataGridViewTextBoxColumn.Name = "lastNameDataGridViewTextBoxColumn";
            // 
            // nationalityDataGridViewTextBoxColumn
            // 
            this.nationalityDataGridViewTextBoxColumn.DataPropertyName = "Nationality";
            this.nationalityDataGridViewTextBoxColumn.HeaderText = "Nationality";
            this.nationalityDataGridViewTextBoxColumn.Name = "nationalityDataGridViewTextBoxColumn";
            // 
            // passportDataGridViewTextBoxColumn
            // 
            this.passportDataGridViewTextBoxColumn.DataPropertyName = "Passport";
            this.passportDataGridViewTextBoxColumn.HeaderText = "Passport";
            this.passportDataGridViewTextBoxColumn.Name = "passportDataGridViewTextBoxColumn";
            // 
            // dOBDataGridViewTextBoxColumn
            // 
            this.dOBDataGridViewTextBoxColumn.DataPropertyName = "DOB";
            this.dOBDataGridViewTextBoxColumn.HeaderText = "DOB";
            this.dOBDataGridViewTextBoxColumn.Name = "dOBDataGridViewTextBoxColumn";
            // 
            // genderDataGridViewTextBoxColumn
            // 
            this.genderDataGridViewTextBoxColumn.DataPropertyName = "Gender";
            this.genderDataGridViewTextBoxColumn.HeaderText = "Gender";
            this.genderDataGridViewTextBoxColumn.Name = "genderDataGridViewTextBoxColumn";
            // 
            // ticketTypeDataGridViewTextBoxColumn
            // 
            this.ticketTypeDataGridViewTextBoxColumn.DataPropertyName = "TicketType";
            this.ticketTypeDataGridViewTextBoxColumn.HeaderText = "TicketType";
            this.ticketTypeDataGridViewTextBoxColumn.Name = "ticketTypeDataGridViewTextBoxColumn";
            // 
            // passengersDataGridViewTextBoxColumn
            // 
            this.passengersDataGridViewTextBoxColumn.DataPropertyName = "Passengers";
            this.passengersDataGridViewTextBoxColumn.HeaderText = "Passengers";
            this.passengersDataGridViewTextBoxColumn.Name = "passengersDataGridViewTextBoxColumn";
            // 
            // flightDateDataGridViewTextBoxColumn
            // 
            this.flightDateDataGridViewTextBoxColumn.DataPropertyName = "FlightDate";
            this.flightDateDataGridViewTextBoxColumn.HeaderText = "FlightDate";
            this.flightDateDataGridViewTextBoxColumn.Name = "flightDateDataGridViewTextBoxColumn";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label3.Location = new System.Drawing.Point(437, 105);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(61, 18);
            this.label3.TabIndex = 69;
            this.label3.Text = "Search";
            // 
            // purchase1TableAdapter
            // 
            this.purchase1TableAdapter.ClearBeforeFill = true;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Final.Properties.Resources._1001449;
            this.pictureBox1.Location = new System.Drawing.Point(897, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(96, 68);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 70;
            this.pictureBox1.TabStop = false;
            // 
            // NOlbl
            // 
            this.NOlbl.AutoSize = true;
            this.NOlbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.NOlbl.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.NOlbl.Location = new System.Drawing.Point(437, 22);
            this.NOlbl.Name = "NOlbl";
            this.NOlbl.Size = new System.Drawing.Size(27, 15);
            this.NOlbl.TabIndex = 72;
            this.NOlbl.Text = "NO";
            // 
            // NOtb
            // 
            this.NOtb.Location = new System.Drawing.Point(517, 22);
            this.NOtb.Name = "NOtb";
            this.NOtb.Size = new System.Drawing.Size(164, 20);
            this.NOtb.TabIndex = 71;
            // 
            // Buy
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkSlateGray;
            this.ClientSize = new System.Drawing.Size(1029, 471);
            this.Controls.Add(this.NOlbl);
            this.Controls.Add(this.NOtb);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.YourFlightCB);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.Passporttb);
            this.Controls.Add(this.Nationalitytb);
            this.Controls.Add(this.Lnametb);
            this.Controls.Add(this.FlightDate);
            this.Controls.Add(this.DOB);
            this.Controls.Add(this.ttypelbl);
            this.Controls.Add(this.passlbl);
            this.Controls.Add(this.fldatelbl);
            this.Controls.Add(this.urflightlbl);
            this.Controls.Add(this.gdrlbl);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.psplbl);
            this.Controls.Add(this.Natlbl);
            this.Controls.Add(this.Lastnamelbl);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Nametb);
            this.Controls.Add(this.SearchBox);
            this.Controls.Add(this.clrbtn);
            this.Controls.Add(this.Closebtn);
            this.Controls.Add(this.upbtn);
            this.Controls.Add(this.delbtn);
            this.Controls.Add(this.addbtn);
            this.Controls.Add(this.FlightdG);
            this.Controls.Add(this.Doblbl);
            this.Controls.Add(this.namelbl);
            this.Name = "Buy";
            this.Text = "Buy";
            this.Load += new System.EventHandler(this.Buy_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.FlightdG)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.purchase1BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.flightDataSet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.purchaseBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.flightDataSet1)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.purchaseBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label Doblbl;
        private System.Windows.Forms.Label namelbl;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton Malerb;
        private System.Windows.Forms.RadioButton Femalerb;
        private System.Windows.Forms.TextBox Passporttb;
        private System.Windows.Forms.TextBox Nationalitytb;
        private System.Windows.Forms.TextBox Lnametb;
        private System.Windows.Forms.DateTimePicker FlightDate;
        private System.Windows.Forms.DateTimePicker DOB;
        private System.Windows.Forms.Label ttypelbl;
        private System.Windows.Forms.Label passlbl;
        private System.Windows.Forms.Label fldatelbl;
        private System.Windows.Forms.Label urflightlbl;
        private System.Windows.Forms.Label gdrlbl;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label psplbl;
        private System.Windows.Forms.Label Natlbl;
        private System.Windows.Forms.Label Lastnamelbl;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox Nametb;
        private System.Windows.Forms.TextBox SearchBox;
        private System.Windows.Forms.Button clrbtn;
        private System.Windows.Forms.Button Closebtn;
        private System.Windows.Forms.Button upbtn;
        private System.Windows.Forms.Button delbtn;
        private System.Windows.Forms.Button addbtn;
        private System.Windows.Forms.DataGridView FlightdG;
        private System.Windows.Forms.ComboBox YourFlightCB;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private FlightDataSet1 flightDataSet1;
        private System.Windows.Forms.BindingSource purchaseBindingSource;
        private FlightDataSet1TableAdapters.PurchaseTableAdapter purchaseTableAdapter;
        private System.Windows.Forms.BindingSource purchaseBindingSource1;
        private System.Windows.Forms.DataGridViewTextBoxColumn yourFlightDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn lastNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nationalityDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn passportDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dOBDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn genderDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn ticketTypeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn passengersDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn flightDateDataGridViewTextBoxColumn;
        private System.Windows.Forms.RadioButton Burb;
        private System.Windows.Forms.RadioButton Ecorb;
        private System.Windows.Forms.RadioButton Infantrb;
        private System.Windows.Forms.RadioButton Adultrb;
        private System.Windows.Forms.RadioButton Childrb;
        private System.Windows.Forms.Label label3;
        private FlightDataSet2 flightDataSet2;
        private System.Windows.Forms.BindingSource purchase1BindingSource;
        private FlightDataSet2TableAdapters.Purchase1TableAdapter purchase1TableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn nODataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn yourFlightDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn nameDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn lastNameDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn nationalityDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn passportDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dOBDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn genderDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn ticketTypeDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn passengersDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn flightDateDataGridViewTextBoxColumn1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label NOlbl;
        private System.Windows.Forms.TextBox NOtb;
    }
}