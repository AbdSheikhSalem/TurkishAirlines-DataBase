﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Final
{
   
    public partial class LogIn : Form
    {
        MainMenu mainmenu = new MainMenu();
        public LogIn()
        {
            InitializeComponent();
        }
        static string conn = ConfigurationManager.ConnectionStrings["Final.Properties.Settings.FlightConnectionString"].ConnectionString;
        private DataTable Select()
        {
            SqlConnection c = new SqlConnection(conn);
            DataTable dTable = new DataTable();

            try
            {
                string sqlCode = "SELECT * FROM SignUp";
                SqlCommand cmd = new SqlCommand(sqlCode, c);
                SqlDataAdapter dataAdapter = new SqlDataAdapter(cmd);
                c.Open();
                dataAdapter.Fill(dTable);

            }
            catch (Exception e)
            {

            }
            finally
            {
                c.Close();
            }

            return dTable;
        }

        private bool Exist(DataTable table, String Username, String Password)
        {
            for (int i = 0; i < table.Rows.Count; i++)
            {
                DataRow row = table.Rows[i];

                if (row[1].Equals(Username))
                    if (row[2].Equals(Password))
                        return true;
            }

            return false;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            DataTable table = Select();
            string Username = usertb.Text;
            string Password = passtb.Text;

            bool isExist = Exist(table, Username, Password);

            if (isExist)
            {
                MessageBox.Show("Welcome Back :)");
                this.Hide();
                mainmenu.Show();
               
            }
            else
            {
                MessageBox.Show("Incorrect username or password!!!");
            }

        }
    }
}
