﻿using Final.Reservations;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Final
{
    public partial class Buy : Form
    {
        Get gt = new Get();
        
        static string myconnstrng = ConfigurationManager.ConnectionStrings["Final.Properties.Settings.FlightConnectionString"].ConnectionString;
        public Buy()
        {
            InitializeComponent();
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void Buy_Load(object sender, EventArgs e)
        {
            this.purchase1TableAdapter.Fill(this.flightDataSet2.Purchase1);
  
            DataTable dt = gt.Select();
            FlightdG.DataSource = dt;
        }

        private void addbtn_Click(object sender, EventArgs e)
        {
            string gender;
            string type;
            string passengers;
            if (Malerb.Checked)
            {
                gender = Malerb.Text;
            }
            else
            {
                gender = Femalerb.Text;
            }

            if (Ecorb.Checked)
            {
                type = Ecorb.Text;
            }
            else
            {
                type = Burb.Text;
            }
            if (Adultrb.Checked)
            {
                passengers = Adultrb.Text;
            }
            else if (Childrb.Checked)
            {
                passengers = Childrb.Text;
            }
            else
            {
                passengers = Infantrb.Text;
            }
    
            gt.Name = Nametb.Text;
            gt.LastName = Lnametb.Text;
            gt.Passport = Passporttb.Text;
            gt.Nationality = Nationalitytb.Text;
            gt.YourFlight = YourFlightCB.Text;
            gt.FlightDate = FlightDate.Text;
            gt.TicketType = type;
            gt.Gender = gender;
            gt.Passengers = passengers;
            gt.DOB = DOB.Text;

            bool success = gt.Add(gt);

            if (success == true)
            {
                MessageBox.Show("A new Reservation has been made");
                Clear();
            }
            else
            {
                MessageBox.Show("Failed");
            }

            DataTable dt = gt.Select();
            FlightdG.DataSource = dt;
        }
        public void Clear()
        {
            YourFlightCB.Text = "";
            Nametb.Text = "";
            Lnametb.Text = "";
            Passporttb.Clear();
            Nationalitytb.Text = String.Empty;
            FlightDate.Text="";
     
            DOB.Text = "";
  
            Malerb.Checked = false;
            Femalerb.Checked = false;
            Adultrb.Checked = false;
            Infantrb.Checked = false;
            Childrb.Checked = false;
            Infantrb.Checked = false;
            Childrb.Checked = false;
            Burb.Checked = false;
            Ecorb.Checked = false;
        }

        private void delbtn_Click(object sender, EventArgs e)
        {

            gt.NO = (int)FlightdG.CurrentRow.Cells[0].Value;
            bool success = gt.Delete(gt);
            if (success)
            {
                MessageBox.Show("Reservation has been cancelled");
                DataTable dt = gt.Select();
                FlightdG.DataSource = dt;

             
                Clear();

            }
            else
            {
          
                MessageBox.Show("Reservation has not been Cancelled");
            }
        }

        private void FlightdG_RowHeaderMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            int index = e.RowIndex;
            string gender;
            string passengers;
            string type;
            if (Malerb.Checked)
            {
                gender = Malerb.Text;
            }
            else
            {
                gender = Femalerb.Text;
            }
            if (Ecorb.Checked)
            {
                type = Ecorb.Text;
            }
            else
            {
                type = Burb.Text;
            }
            if (Adultrb.Checked)
            {
                passengers = Adultrb.Text;
            }
            else if (Childrb.Checked)
            {
                passengers = Childrb.Text;
            }
            else
            {
                passengers = Infantrb.Text;
            }
            NOtb.Text = FlightdG.Rows[index].Cells[0].Value.ToString();
            YourFlightCB.SelectedItem = FlightdG.Rows[index].Cells[1].Value.ToString();
            Nametb.Text = FlightdG.Rows[index].Cells[2].Value.ToString();
            Lnametb.Text = FlightdG.Rows[index].Cells[3].Value.ToString();
            Nationalitytb.Text = FlightdG.Rows[index].Cells[4].Value.ToString();
            Passporttb.Text = FlightdG.Rows[index].Cells[5].Value.ToString();
            DOB.Text = FlightdG.Rows[index].Cells[6].Value.ToString();
            gender = FlightdG.Rows[index].Cells[7].Value.ToString();
            type = FlightdG.Rows[index].Cells[8].Value.ToString();
            passengers = FlightdG.Rows[index].Cells[9].Value.ToString();
            FlightDate.Text = FlightdG.Rows[index].Cells[10].Value.ToString();

        }

        private void SearchBox_TextChanged(object sender, EventArgs e)
        {
            string search = SearchBox.Text;
            SqlConnection conn = new SqlConnection(myconnstrng);
            SqlDataAdapter sda = new SqlDataAdapter("SELECT * FROM Purchase1 WHERE Name LIKE '%" + search + "%' OR NO LIKE '%" + search + "%'", conn);

            DataTable dt = new DataTable();
            sda.Fill(dt);
            FlightdG.DataSource = dt;
        }

        private void upbtn_Click(object sender, EventArgs e)
        {
            string gender;
            string type="";
            string passengers;
            if (Malerb.Checked)
            {
                gender = Malerb.Text;
            }
            else
            {
                gender = Femalerb.Text;
            }

            if (Adultrb.Checked)
            {
                passengers =Adultrb.Text;
            }
            else if (Childrb.Checked)
            {
                passengers = Childrb.Text;
            }
            else
            {
                passengers = Infantrb.Text;
            }
            if (Ecorb.Checked)
            {
                type = Ecorb.Text;
            }
            else if(Burb.Checked)
            {
                type = Burb.Text;
            }
            gt.NO = int.Parse(NOtb.Text);
            gt.Name = Nametb.Text;
            gt.LastName = Lnametb.Text;
            gt.YourFlight = YourFlightCB.Text;
            gt.Nationality = Nationalitytb.Text;
            gt.Passport = Passporttb.Text;
            gt.Gender =gender;
            gt.DOB = DOB.Text;
            gt.TicketType = type;
            gt.Passengers = passengers;
            gt.FlightDate = FlightDate.Text;


            bool success = gt.Update(gt);

            if (success == true)
            {
                MessageBox.Show("Record has been updated");

                DataTable dt = gt.Select();
                FlightdG.DataSource = dt;

                Clear();
            }
            else
            {
                MessageBox.Show("Update Failed");
            }
        }

        private void mainbtn_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Thank you for choosing us :)");
            this.Hide();
           
        }

        private void clrbtn_Click(object sender, EventArgs e)
        {
            Clear();
        }
    }
}
