﻿using Final.Reservations;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Final
{
    public partial class Create1 : Form
    {
        LogIn login = new LogIn();
        Sign std = new Sign();
        public Create1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            std.Username = usertb.Text;
            std.Password = passtb.Text;
            std.Email = emailtb.Text;
            std.Nationality = nationtb.Text;
            std.PhoneNumber = phonetb.Text;

  
            bool success = std.Insert(std);

            if (success == true)
            {
                MessageBox.Show("A new Account has been made");

                if (CBTerms.Checked)
                {
                    this.Hide();
                    login.Show();
                }
                else
                {
                    MessageBox.Show("You have to accept our terms");
                }
            }
            else
            {
                MessageBox.Show("Failed");
            }

        }

    
    }
}
