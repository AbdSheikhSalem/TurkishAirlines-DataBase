﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Final.Reservations
{
    class Sign
    {
          public int ID { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
        public string Email { get; set; }
        public string Nationality { get; set; }
        public string PhoneNumber { get; set; }
        static string myconnstrng = ConfigurationManager.ConnectionStrings["Final.Properties.Settings.FlightConnectionString"].ConnectionString;
        public bool Insert(Sign std)
        {
            bool isSuccess = false;

            SqlConnection conn = new SqlConnection(myconnstrng);

            try
            {

                string sql = "INSERT INTO SignUp (Username, Password, Email,Nationality,PhoneNumber) VALUES (@Username, @Password, @Email,@Nationality,@PhoneNumber) ";
                SqlCommand cmd = new SqlCommand(sql, conn);

                cmd.Parameters.AddWithValue("@Username", std.Username);
                cmd.Parameters.AddWithValue("@Password", std.Password);
                cmd.Parameters.AddWithValue("@Email", std.Email);
                cmd.Parameters.AddWithValue("@Nationality", std.Nationality);
                cmd.Parameters.AddWithValue("@PhoneNumber", std.PhoneNumber);



                conn.Open();

                int rows = cmd.ExecuteNonQuery();


                if (rows > 0)
                {
                    isSuccess = true;
                }
                else
                {
                    isSuccess = false;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conn.Close();
            }

            return isSuccess;
        }
    }
}
