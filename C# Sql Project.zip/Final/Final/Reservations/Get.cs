﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Final.Reservations
{
    class Get
    {
        public int NO { get; set; }
        public string YourFlight { get; set; }
        public string Name { get; set; }
        public string LastName { get; set; }
        public string Nationality { get; set; }
        public string Passport { get; set; }
        public string DOB { get; set; }
        public string Gender { get; set; }
        public string TicketType { get; set; }
        public string Passengers { get; set; }
        public string FlightDate { get; set; }

        static string myconnstrng = ConfigurationManager.ConnectionStrings["Final.Properties.Settings.FlightConnectionString"].ConnectionString;
        public bool Add(Get gt)
        {
            bool isSuccess = false;

            SqlConnection conn = new SqlConnection(myconnstrng);

            try
            {

                string sql = "INSERT INTO Purchase1 (YourFlight, Name, LastName,Nationality,Passport,DOB,Gender,TicketType,Passengers,FlightDate) VALUES (@YourFlight, @Name, @LastName,@Nationality,@Passport,@DOB,@Gender,@TicketType,@Passengers,@FlightDate) ";
                SqlCommand cmd = new SqlCommand(sql, conn);

                cmd.Parameters.AddWithValue("@YourFlight", gt.YourFlight);
                cmd.Parameters.AddWithValue("@Name", gt.Name);
                cmd.Parameters.AddWithValue("@LastName", gt.LastName);
                cmd.Parameters.AddWithValue("@Nationality", gt.Nationality);
                cmd.Parameters.AddWithValue("@Passport", gt.Passport);
                cmd.Parameters.AddWithValue("@DOB", gt.DOB);
                cmd.Parameters.AddWithValue("@Gender", gt.Gender);
                cmd.Parameters.AddWithValue("@TicketType", gt.TicketType);
                cmd.Parameters.AddWithValue("@Passengers", gt.Passengers);
                cmd.Parameters.AddWithValue("@FlightDate", gt.FlightDate);
                

                conn.Open();

                int rows = cmd.ExecuteNonQuery();


                if (rows > 0)
                {
                    isSuccess = true;
                }
                else
                {
                    isSuccess = false;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conn.Close();
            }

            return isSuccess;
        }
        public DataTable Select()
        {
            SqlConnection conn = new SqlConnection(myconnstrng);

            DataTable dt = new DataTable();
            try
            {
                string sql = "SELECT * FROM Purchase1";
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                conn.Open();
                adapter.Fill(dt);
            }
            catch (Exception ex)
            {

            }
            finally
            {
                conn.Close();
            }
            return dt;
        }
        public bool Update(Get gt)
        {
       
            bool isSuccess = false;
            
            SqlConnection conn = new SqlConnection(myconnstrng);
            try
            {
               
                string sql = "UPDATE Purchase1 SET YourFlight=@YourFlight, Name=@Name, LastName=@LastName, Nationality=@Nationality,Passport=@Passport,DOB=@DOB,Gender=@Gender,TicketType=@TicketType,Passengers=@Passengers,FlightDate=@FlightDate WHERE NO=@NO";

        
                SqlCommand cmd = new SqlCommand(sql, conn);

                cmd.Parameters.AddWithValue("@NO", gt.NO);
                cmd.Parameters.AddWithValue("@YourFlight", gt.YourFlight);
                cmd.Parameters.AddWithValue("@Name", gt.Name);
                cmd.Parameters.AddWithValue("@LastName", gt.LastName);
                cmd.Parameters.AddWithValue("@Nationality", gt.Nationality);
                cmd.Parameters.AddWithValue("@Passport", gt.Passport);
                cmd.Parameters.AddWithValue("@DOB", gt.DOB);
                cmd.Parameters.AddWithValue("@Gender", gt.Gender);
                cmd.Parameters.AddWithValue("@TicketType", gt.TicketType);
                cmd.Parameters.AddWithValue("@Passengers", gt.Passengers);
                cmd.Parameters.AddWithValue("@FlightDate", gt.FlightDate);



                conn.Open();

                int rows = cmd.ExecuteNonQuery();

                if (rows > 0)
                {
                    isSuccess = true;
                }
                else
                {
                    isSuccess = false;
                }
            }
            catch (Exception ex)
            {

            }
            finally
            {
                conn.Close();
            }

            return isSuccess;
        }
        public bool Delete(Get gt)
        {
            
            bool isSuccess = false;
           
            SqlConnection conn = new SqlConnection(myconnstrng);
            try
            {
                
                string sql = "DELETE FROM Purchase1 WHERE NO = @NO ";

                SqlCommand cmd = new SqlCommand(sql, conn);

                cmd.Parameters.AddWithValue("@NO", gt.NO);


                conn.Open();

                int rows = cmd.ExecuteNonQuery();

                if (rows > 0)
                {
                    isSuccess = true;
                }
                else
                {
                    isSuccess = false;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conn.Close();
            }

            return isSuccess;
        }
    }
}

 
