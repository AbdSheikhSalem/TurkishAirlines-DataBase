﻿
namespace Final
{
    partial class Create1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.CBTerms = new System.Windows.Forms.CheckBox();
            this.phonetb = new System.Windows.Forms.TextBox();
            this.nationtb = new System.Windows.Forms.TextBox();
            this.emailtb = new System.Windows.Forms.TextBox();
            this.passtb = new System.Windows.Forms.TextBox();
            this.usertb = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(607, 365);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(141, 42);
            this.button1.TabIndex = 23;
            this.button1.Text = "Create";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label5.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label5.Location = new System.Drawing.Point(52, 331);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(104, 18);
            this.label5.TabIndex = 22;
            this.label5.Text = "PhoneNumber";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label4.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label4.Location = new System.Drawing.Point(52, 256);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(76, 18);
            this.label4.TabIndex = 21;
            this.label4.Text = "Nationality";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label3.Location = new System.Drawing.Point(52, 183);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(45, 18);
            this.label3.TabIndex = 20;
            this.label3.Text = "Email";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label2.Location = new System.Drawing.Point(52, 114);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(75, 18);
            this.label2.TabIndex = 19;
            this.label2.Text = "Password";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label1.Location = new System.Drawing.Point(52, 46);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(77, 18);
            this.label1.TabIndex = 18;
            this.label1.Text = "Username";
            // 
            // CBTerms
            // 
            this.CBTerms.AutoSize = true;
            this.CBTerms.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.CBTerms.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.CBTerms.Location = new System.Drawing.Point(55, 385);
            this.CBTerms.Name = "CBTerms";
            this.CBTerms.Size = new System.Drawing.Size(446, 22);
            this.CBTerms.TabIndex = 17;
            this.CBTerms.Text = "I accept The General Terms and Conditions of Miles and Smiles";
            this.CBTerms.UseVisualStyleBackColor = true;
            // 
            // phonetb
            // 
            this.phonetb.Location = new System.Drawing.Point(194, 329);
            this.phonetb.Name = "phonetb";
            this.phonetb.Size = new System.Drawing.Size(162, 20);
            this.phonetb.TabIndex = 16;
            // 
            // nationtb
            // 
            this.nationtb.Location = new System.Drawing.Point(194, 256);
            this.nationtb.Name = "nationtb";
            this.nationtb.Size = new System.Drawing.Size(162, 20);
            this.nationtb.TabIndex = 15;
            // 
            // emailtb
            // 
            this.emailtb.Location = new System.Drawing.Point(194, 181);
            this.emailtb.Name = "emailtb";
            this.emailtb.Size = new System.Drawing.Size(162, 20);
            this.emailtb.TabIndex = 14;
            // 
            // passtb
            // 
            this.passtb.Location = new System.Drawing.Point(194, 112);
            this.passtb.Name = "passtb";
            this.passtb.Size = new System.Drawing.Size(162, 20);
            this.passtb.TabIndex = 13;
            // 
            // usertb
            // 
            this.usertb.Location = new System.Drawing.Point(194, 44);
            this.usertb.Name = "usertb";
            this.usertb.Size = new System.Drawing.Size(162, 20);
            this.usertb.TabIndex = 12;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Final.Properties.Resources._1001449;
            this.pictureBox1.Location = new System.Drawing.Point(607, 33);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(141, 99);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 24;
            this.pictureBox1.TabStop = false;
            // 
            // Create1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkSlateGray;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.CBTerms);
            this.Controls.Add(this.phonetb);
            this.Controls.Add(this.nationtb);
            this.Controls.Add(this.emailtb);
            this.Controls.Add(this.passtb);
            this.Controls.Add(this.usertb);
            this.Name = "Create1";
            this.Text = "Create1";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckBox CBTerms;
        private System.Windows.Forms.TextBox phonetb;
        private System.Windows.Forms.TextBox nationtb;
        private System.Windows.Forms.TextBox emailtb;
        private System.Windows.Forms.TextBox passtb;
        private System.Windows.Forms.TextBox usertb;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}